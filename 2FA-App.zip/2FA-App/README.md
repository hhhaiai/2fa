# 2FA Authentication App

A simple, secure authentication system with optional Two-Factor Authentication (2FA) using TOTP.

## Features

- ✅ User registration and login
- ✅ JWT-based authentication
- ✅ Optional TOTP-based 2FA
- ✅ QR code generation for authenticator apps
- ✅ Rate limiting protection
- ✅ Password hashing with bcrypt
- ✅ Encrypted 2FA secrets
- ✅ Clean, responsive UI

## Tech Stack

**Backend:**
- Node.js + Express
- SQLite (better-sqlite3)
- JWT for authentication
- Speakeasy for TOTP
- bcrypt for password hashing

**Frontend:**
- React + Vite
- React Router
- Tailwind CSS
- QRCode.react

## Project Structure

```
2fa-app/
├── backend/              # Express API server
│   ├── src/
│   │   ├── db/          # Database setup and helpers
│   │   ├── middleware/  # Auth and rate limiting
│   │   ├── routes/      # API endpoints
│   │   ├── utils/       # Encryption and validation
│   │   └── server.js    # Main server file
│   └── package.json
│
└── frontend/            # React application
    ├── src/
    │   ├── components/  # React components
    │   ├── utils/       # API calls and helpers
    │   ├── App.jsx
    │   └── main.jsx
    └── package.json
```

## Quick Start

### Prerequisites

- Node.js 18+ installed
- npm or pnpm installed

### 1. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file from example
cp .env.example .env

# Generate encryption key (copy output to .env)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Edit .env file and set:
# - JWT_SECRET (any long random string)
# - ENCRYPTION_KEY (the key generated above)

# Start the server
npm start
# Or use watch mode for development:
npm run dev
```

The backend will start on http://localhost:3001

### 2. Frontend Setup

```bash
# Navigate to frontend directory (in a new terminal)
cd frontend

# Install dependencies
npm install

# Create .env file from example
cp .env.example .env

# Start the development server
npm run dev
```

The frontend will start on http://localhost:5173

### 3. Open the App

Open your browser and go to: http://localhost:5173

## Environment Variables

### Backend (.env)

```env
PORT=3001
NODE_ENV=development

# Generate with: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
JWT_SECRET=your-super-secret-jwt-key-change-this-to-something-random-and-secure
JWT_EXPIRATION=24h

# Generate with: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
ENCRYPTION_KEY=your-32-byte-hex-encryption-key-change-this-to-something-secure

ALLOWED_ORIGIN=http://localhost:5173
TWO_FA_APP_NAME=MyAuthApp
```

### Frontend (.env)

```env
VITE_API_URL=http://localhost:3001/api
```

## API Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/register` | Register new user | No |
| POST | `/api/login` | Login user | No |
| POST | `/api/verify-2fa` | Verify 2FA code | No |
| GET | `/api/me` | Get current user | Yes |
| POST | `/api/2fa/setup` | Setup 2FA (get QR code) | Yes |
| POST | `/api/2fa/enable` | Enable 2FA | Yes |
| POST | `/api/2fa/disable` | Disable 2FA | Yes |
| POST | `/api/logout` | Logout (client-side) | Yes |

## Usage Flow

### Registration & Login (without 2FA)
1. Register with email, username, and password
2. Login with email and password
3. Access dashboard

### Enabling 2FA
1. From dashboard, click "Enable" under Two-Factor Authentication
2. Scan QR code with authenticator app (Google Authenticator, Authy, etc.)
3. Enter 6-digit code to verify
4. 2FA is now enabled

### Login (with 2FA enabled)
1. Enter email and password
2. Enter 6-digit code from authenticator app
3. Access dashboard

### Disabling 2FA
1. From dashboard, click "Disable" under Two-Factor Authentication
2. Enter your password to confirm
3. 2FA is now disabled

## Security Features

- **Password Hashing**: bcrypt with 10 rounds
- **JWT Tokens**: 24-hour expiration
- **2FA Secret Encryption**: AES-256-GCM
- **Rate Limiting**:
  - Login: 5 attempts per 15 minutes
  - 2FA verify: 3 attempts per 5 minutes
  - Registration: 3 attempts per hour
- **Input Validation**: Email, username, password strength
- **CORS Protection**: Only allowed origin can access API
- **Security Headers**: Helmet middleware

## Development

### Backend Development

```bash
cd backend
npm run dev  # Runs with --watch flag for auto-restart
```

### Frontend Development

```bash
cd frontend
npm run dev  # Hot reload enabled
```

### Building for Production

**Backend:**
```bash
cd backend
# Set NODE_ENV=production in .env
npm start
```

**Frontend:**
```bash
cd frontend
npm run build
npm run preview  # Test production build
```

## Testing

### Manual Testing Checklist

1. ✅ Register new user
2. ✅ Login with correct credentials
3. ✅ Login with wrong credentials (should fail)
4. ✅ Access dashboard when logged in
5. ✅ Access dashboard when not logged in (should redirect)
6. ✅ Enable 2FA
7. ✅ Login with 2FA code
8. ✅ Login with wrong 2FA code (should fail)
9. ✅ Disable 2FA
10. ✅ Test rate limiting (6 failed logins should be blocked)

## Common Issues

### Backend won't start
- Check that `JWT_SECRET` and `ENCRYPTION_KEY` are set in `.env`
- Make sure port 3001 is not already in use
- Run `npm install` to ensure all dependencies are installed

### Frontend can't connect to backend
- Ensure backend is running on port 3001
- Check `VITE_API_URL` in frontend `.env`
- Check CORS settings in backend

### 2FA QR code not showing
- Check browser console for errors
- Ensure QR code library is installed: `npm install qrcode.react`

### Database errors
- Delete `database.db` file and restart backend to recreate

## Database Schema

### users
- `id`: Auto-increment primary key
- `email`: Unique email address
- `username`: Unique username
- `password_hash`: Bcrypt hashed password
- `is_2fa_enabled`: Boolean flag
- `two_fa_secret`: Encrypted TOTP secret
- `created_at`: Timestamp

### login_attempts
- `id`: Auto-increment primary key
- `email`: Email attempted
- `ip_address`: IP of attempt
- `attempted_at`: Timestamp

### temp_2fa_tokens
- `id`: Auto-increment primary key
- `user_id`: Foreign key to users
- `temp_token`: Temporary token for 2FA flow
- `expires_at`: Expiration timestamp
- `created_at`: Timestamp

## License

MIT


## Support

If you encounter issues:
1. Check the console logs (both frontend and backend)
2. Verify environment variables are set correctly
3. Ensure all dependencies are installed
4. Check that both servers are running


