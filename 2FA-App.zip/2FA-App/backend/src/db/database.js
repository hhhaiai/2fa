import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Create database connection
const db = new Database(join(__dirname, '../../database.db'));

// Enable foreign keys
db.pragma('foreign_keys = ON');

// Initialize database schema
function initDatabase() {
  // Users table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      is_2fa_enabled INTEGER DEFAULT 0,
      two_fa_secret TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)
  `);

  // Login attempts table (for rate limiting)
  db.exec(`
    CREATE TABLE IF NOT EXISTS login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      ip_address TEXT NOT NULL,
      attempted_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_login_attempts_email 
    ON login_attempts(email, attempted_at)
  `);

  // Temporary 2FA tokens table
  db.exec(`
    CREATE TABLE IF NOT EXISTS temp_2fa_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      temp_token TEXT UNIQUE NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  console.log('✅ Database initialized successfully');
}

// Helper functions for database operations
export const dbHelpers = {
  // User operations
  createUser: (email, username, passwordHash) => {
    const stmt = db.prepare(
      'INSERT INTO users (email, username, password_hash) VALUES (?, ?, ?)'
    );
    return stmt.run(email, username, passwordHash);
  },

  getUserByEmail: (email) => {
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    return stmt.get(email);
  },

  getUserById: (id) => {
    const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
    return stmt.get(id);
  },

  update2FASecret: (userId, secret) => {
    const stmt = db.prepare(
      'UPDATE users SET two_fa_secret = ? WHERE id = ?'
    );
    return stmt.run(secret, userId);
  },

  enable2FA: (userId) => {
    const stmt = db.prepare(
      'UPDATE users SET is_2fa_enabled = 1 WHERE id = ?'
    );
    return stmt.run(userId);
  },

  disable2FA: (userId) => {
    const stmt = db.prepare(
      'UPDATE users SET is_2fa_enabled = 0, two_fa_secret = NULL WHERE id = ?'
    );
    return stmt.run(userId);
  },

  // Login attempts operations
  recordLoginAttempt: (email, ipAddress) => {
    const stmt = db.prepare(
      'INSERT INTO login_attempts (email, ip_address) VALUES (?, ?)'
    );
    return stmt.run(email, ipAddress);
  },

  getRecentLoginAttempts: (email, minutes = 15) => {
    const stmt = db.prepare(`
      SELECT COUNT(*) as count FROM login_attempts 
      WHERE email = ? 
      AND attempted_at > datetime('now', '-${minutes} minutes')
    `);
    return stmt.get(email);
  },

  clearOldLoginAttempts: () => {
    const stmt = db.prepare(
      "DELETE FROM login_attempts WHERE attempted_at < datetime('now', '-1 hour')"
    );
    return stmt.run();
  },

  // Temp 2FA token operations
  createTempToken: (userId, tempToken, expiresInMinutes = 5) => {
    const stmt = db.prepare(`
      INSERT INTO temp_2fa_tokens (user_id, temp_token, expires_at) 
      VALUES (?, ?, datetime('now', '+${expiresInMinutes} minutes'))
    `);
    return stmt.run(userId, tempToken);
  },

  getTempToken: (tempToken) => {
    const stmt = db.prepare(`
      SELECT * FROM temp_2fa_tokens 
      WHERE temp_token = ? 
      AND expires_at > datetime('now')
    `);
    return stmt.get(tempToken);
  },

  deleteTempToken: (tempToken) => {
    const stmt = db.prepare('DELETE FROM temp_2fa_tokens WHERE temp_token = ?');
    return stmt.run(tempToken);
  },

  clearExpiredTempTokens: () => {
    const stmt = db.prepare(
      "DELETE FROM temp_2fa_tokens WHERE expires_at < datetime('now')"
    );
    return stmt.run();
  }
};

// Initialize database on import
initDatabase();

export default db;
