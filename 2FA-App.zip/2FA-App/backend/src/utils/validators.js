// Email validation
export function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Username validation (3-50 chars, alphanumeric + underscore)
export function isValidUsername(username) {
  const usernameRegex = /^[a-zA-Z0-9_]{3,50}$/;
  return usernameRegex.test(username);
}

// Password validation (min 8 chars, at least 1 uppercase, 1 lowercase, 1 number)
export function isValidPassword(password) {
  if (password.length < 8) return false;
  
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  
  return hasUppercase && hasLowercase && hasNumber;
}

// Validate 2FA code (6 digits)
export function isValid2FACode(code) {
  return /^\d{6}$/.test(code);
}

// Sanitize user input (basic)
export function sanitizeInput(input) {
  if (typeof input !== 'string') return input;
  return input.trim();
}

// Validation middleware factory
export function validateRequest(schema) {
  return (req, res, next) => {
    const errors = [];
    
    for (const [field, rules] of Object.entries(schema)) {
      const value = req.body[field];
      
      // Check required
      if (rules.required && !value) {
        errors.push(`${field} is required`);
        continue;
      }
      
      // Skip validation if field is optional and not provided
      if (!rules.required && !value) continue;
      
      // Run validator
      if (rules.validator && !rules.validator(value)) {
        errors.push(rules.message || `${field} is invalid`);
      }
    }
    
    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Validation failed',
          details: errors
        }
      });
    }
    
    next();
  };
}
