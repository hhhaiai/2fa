import jwt from 'jsonwebtoken';
import { dbHelpers } from '../db/database.js';

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({
      success: false,
      error: {
        code: 'AUTH_001',
        message: 'Authentication token required'
      }
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Get user from database to ensure they still exist
    const user = dbHelpers.getUserById(decoded.userId);
    
    if (!user) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_004',
          message: 'Invalid token - user not found'
        }
      });
    }
    
    // Attach user to request
    req.user = {
      userId: user.id,
      email: user.email,
      username: user.username
    };
    
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_003',
          message: 'Token expired'
        }
      });
    }
    
    return res.status(403).json({
      success: false,
      error: {
        code: 'AUTH_004',
        message: 'Invalid token'
      }
    });
  }
}
