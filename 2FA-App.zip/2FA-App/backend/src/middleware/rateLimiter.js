import rateLimit from 'express-rate-limit';

// Rate limiter for login endpoint (5 attempts per 15 minutes)
export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 requests per window
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_001',
      message: 'Too many login attempts. Please try again in 15 minutes.'
    }
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for 2FA verification (3 attempts per 5 minutes)
export const twoFALimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 3, // 3 requests per window
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_001',
      message: 'Too many verification attempts. Please try again in 5 minutes.'
    }
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter for registration (3 attempts per hour)
export const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // 3 requests per window
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_001',
      message: 'Too many registration attempts. Please try again later.'
    }
  },
  standardHeaders: true,
  legacyHeaders: false,
});
