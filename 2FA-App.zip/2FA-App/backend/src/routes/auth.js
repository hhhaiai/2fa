import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';
import { dbHelpers } from '../db/database.js';
import { authenticateToken } from '../middleware/auth.js';
import { loginLimiter, twoFALimiter, registerLimiter } from '../middleware/rateLimiter.js';
import {
  isValidEmail,
  isValidUsername,
  isValidPassword,
  isValid2FACode,
  sanitizeInput,
  validateRequest
} from '../utils/validators.js';
import { encrypt, decrypt } from '../utils/encryption.js';
import crypto from 'crypto';

const router = express.Router();

// ============================================
// 1. REGISTER
// ============================================
router.post('/register', registerLimiter, validateRequest({
  email: {
    required: true,
    validator: isValidEmail,
    message: 'Invalid email format'
  },
  username: {
    required: true,
    validator: isValidUsername,
    message: 'Username must be 3-50 characters, alphanumeric and underscore only'
  },
  password: {
    required: true,
    validator: isValidPassword,
    message: 'Password must be at least 8 characters with uppercase, lowercase, and number'
  }
}), async (req, res) => {
  try {
    const { email, username, password } = req.body;
    
    const sanitizedEmail = sanitizeInput(email).toLowerCase();
    const sanitizedUsername = sanitizeInput(username);
    
    // Check if user already exists
    const existingUser = dbHelpers.getUserByEmail(sanitizedEmail);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_001',
          message: 'Email already registered'
        }
      });
    }
    
    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);
    
    // Create user
    const result = dbHelpers.createUser(sanitizedEmail, sanitizedUsername, passwordHash);
    
    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      data: {
        userId: result.lastInsertRowid,
        email: sanitizedEmail,
        username: sanitizedUsername
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    
    if (error.message.includes('UNIQUE constraint failed: users.username')) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_001',
          message: 'Username already taken'
        }
      });
    }
    
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: 'Registration failed'
      }
    });
  }
});

// ============================================
// 2. LOGIN
// ============================================
router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_002',
          message: 'Email and password are required'
        }
      });
    }
    
    const sanitizedEmail = sanitizeInput(email).toLowerCase();
    
    // Get user
    const user = dbHelpers.getUserByEmail(sanitizedEmail);
    
    if (!user) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_001',
          message: 'Invalid credentials'
        }
      });
    }
    
    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_001',
          message: 'Invalid credentials'
        }
      });
    }
    
    // Check if 2FA is enabled
    if (user.is_2fa_enabled) {
      // Generate temporary token for 2FA verification
      const tempToken = crypto.randomBytes(32).toString('hex');
      
      // Store temp token in database
      dbHelpers.createTempToken(user.id, tempToken, 5); // 5 minutes expiration
      
      return res.json({
        success: true,
        requires2FA: true,
        data: {
          tempToken
        }
      });
    }
    
    // No 2FA - generate full JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRATION || '24h' }
    );
    
    res.json({
      success: true,
      data: {
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          is2FAEnabled: Boolean(user.is_2fa_enabled)
        }
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: 'Login failed'
      }
    });
  }
});

// ============================================
// 3. VERIFY 2FA
// ============================================
router.post('/verify-2fa', twoFALimiter, async (req, res) => {
  try {
    const { tempToken, code } = req.body;
    
    if (!tempToken || !code) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_002',
          message: 'Temporary token and code are required'
        }
      });
    }
    
    if (!isValid2FACode(code)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_001',
          message: 'Invalid code format'
        }
      });
    }
    
    // Get temp token from database
    const tokenData = dbHelpers.getTempToken(tempToken);
    
    if (!tokenData) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_005',
          message: 'Invalid or expired temporary token'
        }
      });
    }
    
    // Get user
    const user = dbHelpers.getUserById(tokenData.user_id);
    
    if (!user || !user.two_fa_secret) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_007',
          message: '2FA not properly configured'
        }
      });
    }
    
    // Decrypt secret
    const secret = decrypt(user.two_fa_secret);
    
    // Verify TOTP code
    const isValid = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: code,
      window: 1 // Allow 1 step before/after for clock drift
    });
    
    if (!isValid) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_006',
          message: 'Invalid 2FA code'
        }
      });
    }
    
    // Delete temp token
    dbHelpers.deleteTempToken(tempToken);
    
    // Generate full JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRATION || '24h' }
    );
    
    res.json({
      success: true,
      data: {
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          is2FAEnabled: Boolean(user.is_2fa_enabled)
        }
      }
    });
  } catch (error) {
    console.error('2FA verification error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: '2FA verification failed'
      }
    });
  }
});

// ============================================
// 4. GET CURRENT USER
// ============================================
router.get('/me', authenticateToken, (req, res) => {
  try {
    const user = dbHelpers.getUserById(req.user.userId);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'AUTH_004',
          message: 'User not found'
        }
      });
    }
    
    res.json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        username: user.username,
        is2FAEnabled: Boolean(user.is_2fa_enabled),
        createdAt: user.created_at
      }
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: 'Failed to get user information'
      }
    });
  }
});

// ============================================
// 5. SETUP 2FA
// ============================================
router.post('/2fa/setup', authenticateToken, async (req, res) => {
  try {
    const user = dbHelpers.getUserById(req.user.userId);
    
    // Generate new secret
    const secret = speakeasy.generateSecret({
      name: `${process.env.TWO_FA_APP_NAME || 'MyAuthApp'} (${user.email})`
    });
    
    // Encrypt and store secret (not enabled yet)
    const encryptedSecret = encrypt(secret.base32);
    dbHelpers.update2FASecret(user.id, encryptedSecret);
    
    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);
    
    res.json({
      success: true,
      data: {
        secret: secret.base32,
        qrCode: qrCodeUrl
      }
    });
  } catch (error) {
    console.error('2FA setup error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: '2FA setup failed'
      }
    });
  }
});

// ============================================
// 6. ENABLE 2FA
// ============================================
router.post('/2fa/enable', authenticateToken, async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code || !isValid2FACode(code)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_001',
          message: 'Valid 6-digit code is required'
        }
      });
    }
    
    const user = dbHelpers.getUserById(req.user.userId);
    
    if (!user.two_fa_secret) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'AUTH_007',
          message: 'Please setup 2FA first'
        }
      });
    }
    
    // Decrypt secret
    const secret = decrypt(user.two_fa_secret);
    
    // Verify the code
    const isValid = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: code,
      window: 1
    });
    
    if (!isValid) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_006',
          message: 'Invalid 2FA code'
        }
      });
    }
    
    // Enable 2FA
    dbHelpers.enable2FA(user.id);
    
    res.json({
      success: true,
      message: '2FA enabled successfully'
    });
  } catch (error) {
    console.error('Enable 2FA error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: 'Failed to enable 2FA'
      }
    });
  }
});

// ============================================
// 7. DISABLE 2FA
// ============================================
router.post('/2fa/disable', authenticateToken, async (req, res) => {
  try {
    const { password } = req.body;
    
    if (!password) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_002',
          message: 'Password is required to disable 2FA'
        }
      });
    }
    
    const user = dbHelpers.getUserById(req.user.userId);
    
    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'AUTH_001',
          message: 'Invalid password'
        }
      });
    }
    
    // Disable 2FA
    dbHelpers.disable2FA(user.id);
    
    res.json({
      success: true,
      message: '2FA disabled successfully'
    });
  } catch (error) {
    console.error('Disable 2FA error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_001',
        message: 'Failed to disable 2FA'
      }
    });
  }
});

// ============================================
// 8. LOGOUT (optional - mainly client-side)
// ============================================
router.post('/logout', authenticateToken, (req, res) => {
  // In a stateless JWT setup, logout is handled client-side by removing the token
  // This endpoint exists for consistency and future session management
  res.json({
    success: true,
    message: 'Logged out successfully'
  });
});

export default router;
