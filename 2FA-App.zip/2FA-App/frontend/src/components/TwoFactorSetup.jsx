import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { api } from '../utils/api';

export default function TwoFactorSetup() {
  const navigate = useNavigate();
  const [qrData, setQrData] = useState(null);
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [enabling, setEnabling] = useState(false);

  useEffect(() => {
    setup2FA();
  }, []);

  const setup2FA = async () => {
    try {
      const response = await api.setup2FA();
      setQrData(response.data);
    } catch (err) {
      setError(err.message || 'Failed to setup 2FA');
    } finally {
      setLoading(false);
    }
  };

  const handleEnable = async (e) => {
    e.preventDefault();
    setError('');
    setEnabling(true);

    try {
      await api.enable2FA(code);
      // Success! Redirect to dashboard
      navigate('/dashboard', {
        state: { message: '2FA enabled successfully!' }
      });
    } catch (err) {
      setError(err.message || 'Invalid code');
      setCode('');
    } finally {
      setEnabling(false);
    }
  };

  const handleCancel = () => {
    navigate('/dashboard');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Enable Two-Factor Authentication
            </h3>
            <div className="mt-2 max-w-xl text-sm text-gray-500">
              <p>
                Scan the QR code below with your authenticator app (like Google Authenticator or Authy),
                then enter the 6-digit code to verify.
              </p>
            </div>

            {error && (
              <div className="mt-4 rounded-md bg-red-50 p-4">
                <div className="text-sm text-red-800">{error}</div>
              </div>
            )}

            <div className="mt-6">
              {/* QR Code */}
              <div className="flex justify-center p-6 bg-white border-2 border-gray-200 rounded-lg">
                {qrData?.qrCode ? (
                  <img src={qrData.qrCode} alt="QR Code" className="w-64 h-64" />
                ) : (
                  <div className="w-64 h-64 flex items-center justify-center text-gray-400">
                    No QR code available
                  </div>
                )}
              </div>

              {/* Secret Key (manual entry) */}
              {qrData?.secret && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm font-medium text-gray-700">
                    Can't scan the QR code? Enter this key manually:
                  </p>
                  <p className="mt-2 text-sm font-mono text-gray-900 break-all">
                    {qrData.secret}
                  </p>
                </div>
              )}

              {/* Verification Form */}
              <form onSubmit={handleEnable} className="mt-6">
                <label htmlFor="code" className="block text-sm font-medium text-gray-700">
                  Enter 6-digit code from your authenticator app
                </label>
                <div className="mt-2">
                  <input
                    type="text"
                    id="code"
                    inputMode="numeric"
                    pattern="\d{6}"
                    maxLength={6}
                    required
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-center text-2xl tracking-widest"
                    placeholder="000000"
                    value={code}
                    onChange={(e) => {
                      setCode(e.target.value.replace(/\D/g, ''));
                      setError('');
                    }}
                    disabled={enabling}
                  />
                </div>

                <div className="mt-6 flex space-x-3">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="flex-1 bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={enabling || code.length !== 6}
                    className="flex-1 bg-indigo-600 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {enabling ? 'Verifying...' : 'Enable 2FA'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
