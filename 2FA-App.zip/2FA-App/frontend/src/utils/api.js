const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Helper function to make API calls
async function apiCall(endpoint, options = {}) {
  const token = localStorage.getItem('token');
  
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  
  if (token && !options.skipAuth) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers,
  });
  
  const data = await response.json();
  
  if (!response.ok) {
    throw new Error(data.error?.message || 'An error occurred');
  }
  
  return data;
}

// Auth API functions
export const api = {
  // Register new user
  register: async (email, username, password) => {
    return apiCall('/register', {
      method: 'POST',
      skipAuth: true,
      body: JSON.stringify({ email, username, password }),
    });
  },
  
  // Login
  login: async (email, password) => {
    return apiCall('/login', {
      method: 'POST',
      skipAuth: true,
      body: JSON.stringify({ email, password }),
    });
  },
  
  // Verify 2FA code
  verify2FA: async (tempToken, code) => {
    return apiCall('/verify-2fa', {
      method: 'POST',
      skipAuth: true,
      body: JSON.stringify({ tempToken, code }),
    });
  },
  
  // Get current user
  getCurrentUser: async () => {
    return apiCall('/me');
  },
  
  // Setup 2FA (get QR code)
  setup2FA: async () => {
    return apiCall('/2fa/setup', {
      method: 'POST',
    });
  },
  
  // Enable 2FA
  enable2FA: async (code) => {
    return apiCall('/2fa/enable', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });
  },
  
  // Disable 2FA
  disable2FA: async (password) => {
    return apiCall('/2fa/disable', {
      method: 'POST',
      body: JSON.stringify({ password }),
    });
  },
  
  // Logout
  logout: async () => {
    return apiCall('/logout', {
      method: 'POST',
    });
  },
};

// Auth helper functions
export const auth = {
  getToken: () => localStorage.getItem('token'),
  setToken: (token) => localStorage.setItem('token', token),
  removeToken: () => localStorage.removeItem('token'),
  isAuthenticated: () => !!localStorage.getItem('token'),
};
