# 🚀 Quick Start Guide

## Get Up and Running in 5 Minutes

### Step 1: Install Dependencies

```bash
# Backend
cd backend
npm install

# Frontend (in a new terminal)
cd frontend
npm install
```

### Step 2: Setup Environment Variables

**Option A - Automated (Recommended):**
```bash
# Run from the project root
node setup.js
```

**Option B - Manual:**

Create `backend/.env`:
```env
JWT_SECRET=your-long-random-secret-here
ENCRYPTION_KEY=your-64-character-hex-key-here
PORT=3001
ALLOWED_ORIGIN=http://localhost:5173
```

Generate keys with:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Create `frontend/.env`:
```env
VITE_API_URL=http://localhost:3001/api
```

### Step 3: Start the Servers

**Terminal 1 - Backend:**
```bash
cd backend
npm start
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

### Step 4: Open the App

🌐 Open http://localhost:5173 in your browser

## First Time Usage

1. **Register** - Create an account
2. **Login** - Sign in with your credentials
3. **Enable 2FA** (optional):
   - Click "Enable" under Two-Factor Authentication
   - Scan QR code with Google Authenticator or Authy
   - Enter the 6-digit code
4. **Test** - Logout and login again with 2FA

## Troubleshooting

**Backend won't start?**
- Make sure `.env` file exists in `backend/` folder
- Check that ports 3001 is available
- Verify `JWT_SECRET` and `ENCRYPTION_KEY` are set

**Frontend can't connect?**
- Ensure backend is running first
- Check `.env` file in `frontend/` folder
- Verify `VITE_API_URL` points to http://localhost:3001/api

**Need to reset?**
- Delete `backend/database.db`
- Restart backend server

## What's Next?

Check out `README.md` for:
- Complete API documentation
- Security features
- Testing guide
- Production deployment
- Future enhancements

## Project Structure

```
2fa-app/
├── backend/         # API server (Express + SQLite)
├── frontend/        # React app (Vite + Tailwind)
├── README.md        # Full documentation
├── setup.js         # Automated setup script
└── QUICK_START.md   # This file
```

Happy coding! 🎉
