#!/usr/bin/env node

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🔧 Setting up 2FA Authentication App...\n');

// Generate secure random keys
const jwtSecret = crypto.randomBytes(32).toString('hex');
const encryptionKey = crypto.randomBytes(32).toString('hex');

console.log('✅ Generated secure keys');

// Backend .env content
const backendEnv = `# Server Configuration
PORT=3001
NODE_ENV=development

# JWT Configuration
JWT_SECRET=${jwtSecret}
JWT_EXPIRATION=24h

# Encryption Key for 2FA Secrets
ENCRYPTION_KEY=${encryptionKey}

# CORS
ALLOWED_ORIGIN=http://localhost:5173

# 2FA App Name
TWO_FA_APP_NAME=MyAuthApp
`;

// Frontend .env content
const frontendEnv = `VITE_API_URL=http://localhost:3001/api
`;

// Write backend .env
const backendEnvPath = path.join(__dirname, 'backend', '.env');
if (!fs.existsSync(backendEnvPath)) {
  fs.writeFileSync(backendEnvPath, backendEnv);
  console.log('✅ Created backend/.env');
} else {
  console.log('⚠️  backend/.env already exists, skipping');
}

// Write frontend .env
const frontendEnvPath = path.join(__dirname, 'frontend', '.env');
if (!fs.existsSync(frontendEnvPath)) {
  fs.writeFileSync(frontendEnvPath, frontendEnv);
  console.log('✅ Created frontend/.env');
} else {
  console.log('⚠️  frontend/.env already exists, skipping');
}

console.log('\n🎉 Setup complete!\n');
console.log('Next steps:');
console.log('1. cd backend && npm install');
console.log('2. cd frontend && npm install');
console.log('3. Start backend: cd backend && npm start');
console.log('4. Start frontend: cd frontend && npm run dev');
console.log('\nOpen http://localhost:5173 in your browser\n');
