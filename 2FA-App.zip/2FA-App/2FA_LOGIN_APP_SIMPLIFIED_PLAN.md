# 2FA Login App - SIMPLIFIED Project Plan

## Project Overview

### Simplified Goal
Build a minimal but functional authentication system with optional 2FA in the shortest time possible.

### What We're KEEPING
✅ User registration (email + password)
✅ Login/logout with JWT
✅ TOTP-based 2FA (optional for users)
✅ Basic password security (bcrypt)
✅ Protected routes
✅ Simple rate limiting

### What We're REMOVING (for speed)
❌ Refresh tokens (access tokens only)
❌ Session management table
❌ Backup codes
❌ Account lockout
❌ Audit logging
❌ Redis
❌ Multiple device sessions
❌ TypeScript (using JavaScript for speed)
❌ Comprehensive testing (basic tests only)
❌ Complex error handling

### Estimated Timeline
**7-10 days** instead of 22 days

---

## Simplified Technology Stack

### Frontend
- **Framework**: React (JavaScript, not TypeScript)
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **HTTP**: Fetch API (no axios needed)
- **QR Code**: qrcode.react
- **Form Handling**: Plain React state (no form libraries)

### Backend
- **Runtime**: Node.js
- **Framework**: Express (JavaScript)
- **Database**: SQLite (file-based, no PostgreSQL setup needed)
- **ORM**: Better-sqlite3 (simpler than Prisma)
- **Authentication**: 
  - jsonwebtoken
  - bcrypt
  - speakeasy (2FA)
- **Rate Limiting**: express-rate-limit
- **Security**: helmet, cors

### Development
- **Version Control**: Git
- **Package Manager**: npm
- **Testing**: Basic manual testing + 5-10 critical automated tests
- **Deployment**: Simple Docker container or direct Node.js

---

## Simplified Database Schema

### Single SQLite Database with 3 Tables

```sql
-- users table
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  is_2fa_enabled INTEGER DEFAULT 0,
  two_fa_secret TEXT, -- encrypted
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);

-- login_attempts table (simple rate limiting)
CREATE TABLE login_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL,
  ip_address TEXT NOT NULL,
  attempted_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_login_attempts_email ON login_attempts(email, attempted_at);

-- temp_2fa_tokens table (for 2FA verification step)
CREATE TABLE temp_2fa_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  temp_token TEXT UNIQUE NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

---

## Simplified API Endpoints

### Only 8 Endpoints Total

#### 1. `POST /api/register`
Register new user
```json
Request: { "email": "user@example.com", "username": "john", "password": "pass123" }
Response: { "success": true, "userId": 1 }
```

#### 2. `POST /api/login`
Login (returns full token if no 2FA, temp token if 2FA enabled)
```json
Request: { "email": "user@example.com", "password": "pass123" }
Response (no 2FA): { "token": "jwt...", "user": {...} }
Response (with 2FA): { "requires2FA": true, "tempToken": "temp..." }
```

#### 3. `POST /api/verify-2fa`
Complete login with 2FA code
```json
Request: { "tempToken": "temp...", "code": "123456" }
Response: { "token": "jwt...", "user": {...} }
```

#### 4. `GET /api/me`
Get current user (requires auth)
```json
Response: { "id": 1, "email": "user@example.com", "username": "john", "is2FAEnabled": true }
```

#### 5. `POST /api/2fa/setup`
Generate QR code for 2FA setup (requires auth)
```json
Response: { "secret": "base32...", "qrCodeUrl": "otpauth://..." }
```

#### 6. `POST /api/2fa/enable`
Verify and enable 2FA (requires auth)
```json
Request: { "code": "123456" }
Response: { "success": true }
```

#### 7. `POST /api/2fa/disable`
Disable 2FA (requires auth + password)
```json
Request: { "password": "pass123" }
Response: { "success": true }
```

#### 8. `POST /api/logout`
Logout (client-side token removal, optional endpoint)
```json
Response: { "success": true }
```

---

## Simplified Project Structure

```
2fa-app/
├── backend/
│   ├── src/
│   │   ├── db/
│   │   │   ├── database.js        # SQLite connection
│   │   │   └── init.sql           # Schema
│   │   ├── middleware/
│   │   │   ├── auth.js            # JWT verification
│   │   │   └── rateLimiter.js     # Rate limiting
│   │   ├── routes/
│   │   │   └── auth.js            # All auth endpoints
│   │   ├── utils/
│   │   │   ├── encryption.js      # 2FA secret encryption
│   │   │   └── validators.js      # Input validation
│   │   └── server.js              # Main app file
│   ├── .env
│   ├── .gitignore
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Login.jsx
│   │   │   ├── Register.jsx
│   │   │   ├── TwoFactorVerify.jsx
│   │   │   ├── TwoFactorSetup.jsx
│   │   │   └── Dashboard.jsx
│   │   ├── utils/
│   │   │   └── api.js             # API calls
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── .env
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
├── .gitignore
└── README.md
```

---

## SIMPLIFIED Development Phases

### Phase 1: Setup (Day 1)
**Time**: 2-3 hours

**Backend**:
- [x] Initialize Node.js project
- [x] Install dependencies: express, bcrypt, jsonwebtoken, speakeasy, better-sqlite3, cors, helmet, express-rate-limit, dotenv
- [x] Create SQLite database and schema
- [x] Basic server.js with Express setup

**Frontend**:
- [x] Create React app with Vite
- [x] Install dependencies: react-router-dom, qrcode.react
- [x] Install Tailwind CSS
- [x] Basic routing setup

**Deliverable**: Both servers running

---

### Phase 2: Basic Auth (Days 2-3)
**Time**: 6-8 hours

**Backend**:
- [x] Registration endpoint with bcrypt
- [x] Login endpoint with JWT
- [x] Auth middleware
- [x] /me endpoint

**Frontend**:
- [x] Register form
- [x] Login form
- [x] Dashboard page
- [x] Protected routes
- [x] Token storage in localStorage

**Testing**: Manual test register → login → access dashboard

**Deliverable**: Working login/register without 2FA

---

### Phase 3: 2FA Implementation (Days 4-6)
**Time**: 8-10 hours

**Backend**:
- [x] Encryption utility for 2FA secrets
- [x] /2fa/setup endpoint (generate secret + QR)
- [x] /2fa/enable endpoint (verify code)
- [x] /2fa/disable endpoint
- [x] Modify login to check for 2FA
- [x] /verify-2fa endpoint
- [x] Temp token management

**Frontend**:
- [x] 2FA setup page (QR code display)
- [x] 2FA verification during login
- [x] 2FA settings toggle
- [x] Update login flow for 2FA redirect

**Testing**: Manual test full 2FA flow

**Deliverable**: Complete 2FA working

---

### Phase 4: Security & Polish (Day 7)
**Time**: 4-6 hours

**Backend**:
- [x] Rate limiting on login/2fa endpoints
- [x] Input validation
- [x] Better error messages
- [x] CORS configuration

**Frontend**:
- [x] Loading states
- [x] Error handling UI
- [x] Better form validation
- [x] Responsive design fixes

**Testing**: Test rate limiting, error cases

**Deliverable**: Production-ready app

---

### Phase 5: Testing & Deployment (Days 8-10, optional)
**Time**: 4-6 hours

**Tasks**:
- [x] Write 5-10 critical tests
- [x] Documentation
- [x] Deployment prep
- [x] Environment variables
- [x] Docker setup (optional)

**Deliverable**: Deployed app

---

## Simplified Security Approach

### What We Keep
✅ **Password Hashing**: bcrypt with rounds=10
✅ **JWT Tokens**: 24-hour expiration (no refresh tokens)
✅ **2FA Secret Encryption**: AES-256
✅ **Rate Limiting**: 5 login attempts per 15 minutes per IP
✅ **Input Validation**: Basic email/password validation
✅ **HTTPS**: Required in production

### What We Simplified
⚠️ **No Session Management**: Stateless JWT only
⚠️ **No Account Lockout**: Rate limiting only
⚠️ **No Audit Logs**: Basic console logging
⚠️ **Longer Token Expiration**: 24 hours instead of 15 minutes
⚠️ **Single Device**: No multi-device session tracking

---

## Environment Variables

### Backend (.env)
```bash
PORT=3001
JWT_SECRET=your-secret-key-min-32-characters-long
JWT_EXPIRATION=24h
ENCRYPTION_KEY=your-32-byte-hex-key-for-2fa-secrets
ALLOWED_ORIGIN=http://localhost:5173
NODE_ENV=development
```

### Frontend (.env)
```bash
VITE_API_URL=http://localhost:3001/api
```

---

## Key Dependencies

### Backend (package.json)
```json
{
  "dependencies": {
    "express": "^4.18.2",
    "bcrypt": "^5.1.1",
    "jsonwebtoken": "^9.0.2",
    "speakeasy": "^2.0.0",
    "better-sqlite3": "^9.2.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "express-rate-limit": "^7.1.5",
    "dotenv": "^16.3.1",
    "qrcode": "^1.5.3"
  }
}
```

### Frontend (package.json)
```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.1",
    "qrcode.react": "^3.1.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "vite": "^5.0.8",
    "tailwindcss": "^3.4.0"
  }
}
```

---

## Trade-offs Made for Speed

| Feature Removed | Impact | Mitigation |
|----------------|--------|------------|
| Refresh tokens | Users must re-login every 24h | Acceptable for MVP |
| Account lockout | Vulnerable to brute force | Rate limiting helps |
| Session table | Can't revoke tokens | Short token expiration |
| Audit logs | No security tracking | Add later if needed |
| TypeScript | Less type safety | Write cleaner JS |
| Comprehensive tests | Less confidence | Test critical paths manually |
| Backup codes | Users locked out if phone lost | Can add in v2 |

---

## Testing Strategy (Minimal)

### Critical Manual Tests (15 minutes)
1. Register new user ✓
2. Login with correct password ✓
3. Login with wrong password (should fail) ✓
4. Access dashboard when logged in ✓
5. Access dashboard when not logged in (should redirect) ✓
6. Enable 2FA ✓
7. Login with 2FA code ✓
8. Login with wrong 2FA code (should fail) ✓
9. Disable 2FA ✓
10. Test rate limiting (try 6 failed logins) ✓

### Optional Automated Tests (5 tests)
1. Password hashing works
2. JWT generation and verification
3. TOTP code verification
4. Registration validation
5. Login endpoint

---

## Minimum Viable Features Checklist

### Must Have ✅
- [x] User registration
- [x] Login with password
- [x] JWT authentication
- [x] Protected routes
- [x] 2FA setup (QR code)
- [x] 2FA verification on login
- [x] Enable/disable 2FA
- [x] Basic rate limiting
- [x] Password hashing

### Nice to Have (Skip for MVP) ⏭️
- [ ] Refresh tokens
- [ ] Email verification
- [ ] Password reset
- [ ] Backup codes
- [ ] Account lockout
- [ ] Audit logging
- [ ] Session management
- [ ] Multiple devices
- [ ] Admin panel

---

## Quick Start Commands

### Backend Setup
```bash
cd backend
npm init -y
npm install express bcrypt jsonwebtoken speakeasy better-sqlite3 cors helmet express-rate-limit dotenv qrcode
node src/server.js
```

### Frontend Setup
```bash
npm create vite@latest frontend -- --template react
cd frontend
npm install
npm install react-router-dom qrcode.react
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
npm run dev
```

---

## Success Criteria (Simplified)

### For MVP Completion
- [x] User can register and login
- [x] JWT tokens work
- [x] User can enable 2FA
- [x] 2FA login flow works
- [x] Basic security measures in place (hashing, rate limiting)
- [x] App is deployed and accessible
- [x] 10 critical tests pass

### Time Saved
- **Original Plan**: 22 days
- **Simplified Plan**: 7-10 days
- **Time Saved**: ~12-15 days (50%+ reduction)

---

## What to Build in Each Phase (Quick Reference)

**Day 1**: Get both servers running + database  
**Day 2**: Registration + Login (no 2FA)  
**Day 3**: Protected routes + dashboard  
**Day 4**: 2FA setup backend  
**Day 5**: 2FA setup frontend  
**Day 6**: 2FA login flow  
**Day 7**: Security, polish, testing  
**Days 8-10**: Deploy (optional)

---

## When to Add Back Features

After MVP is working, you can add:

1. **Week 2**: Refresh tokens + session management
2. **Week 3**: Backup codes + account lockout
3. **Week 4**: Audit logging + admin features
4. **Week 5**: Email verification + password reset
5. **Week 6**: TypeScript migration (optional)

---

## Next Steps

1. ✅ Review this simplified plan
2. ⬜ Set up development environment (Day 1)
3. ⬜ Start Phase 2 (Registration + Login)
4. ⬜ Implement each phase in order
5. ⬜ Test thoroughly before moving forward
6. ⬜ Deploy when MVP is complete

**Ready to start building?** Let me know and I'll help you implement Phase 1!

