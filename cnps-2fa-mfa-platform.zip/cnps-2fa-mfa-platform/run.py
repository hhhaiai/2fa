# run.py
"""Application Entry Point"""

import os
from backend.app import create_app
from backend.config import DevelopmentConfig

if __name__ == '__main__':
    # Get environment
    env = os.getenv('FLASK_ENV', 'development')
    
    # Create app
    app = create_app()
    
    # Run Flask development server
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )