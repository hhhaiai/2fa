# tests/integration/test_auth_flow.py
"""Integration Tests for Complete 2FA Flow"""

import pytest
import json
from backend.app import create_app
from backend.config import TestingConfig

@pytest.fixture
def app():
    """Create test application"""
    app = create_app(TestingConfig)
    return app

@pytest.fixture
def client(app):
    """Create test client"""
    return app.test_client()

class TestComplete2FAFlow:
    """Test complete 2FA authentication flow"""
    
    def test_health_check(self, client):
        """Test health check endpoint"""
        response = client.get('/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'
    
    def test_initiate_2fa_success(self, client):
        """Test successful 2FA initiation"""
        payload = {
            'username': 'testuser1',
            'password': 'TestPass123!',
            'app_name': 'e-declaration'
        }
        response = client.post('/auth/initiate-2fa', 
                              data=json.dumps(payload),
                              content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'pending_otp'
        assert 'session_id' in data
        assert 'message' in data
    
    def test_initiate_2fa_invalid_credentials(self, client):
        """Test 2FA initiation with invalid credentials"""
        payload = {
            'username': 'testuser1',
            'password': 'WrongPassword',
            'app_name': 'e-declaration'
        }
        response = client.post('/auth/initiate-2fa',
                              data=json.dumps(payload),
                              content_type='application/json')
        
        assert response.status_code == 401
        data = json.loads(response.data)
        assert data['status'] == 'error'
    
    def test_initiate_2fa_missing_fields(self, client):
        """Test 2FA initiation with missing fields"""
        payload = {
            'username': 'testuser1'
            # Missing password and app_name
        }
        response = client.post('/auth/initiate-2fa',
                              data=json.dumps(payload),
                              content_type='application/json')
        
        assert response.status_code == 400
    
    def test_complete_2fa_flow(self, client):
        """Test complete 2FA flow: initiate -> validate"""
        # Step 1: Initiate 2FA
        payload_initiate = {
            'username': 'testuser1',
            'password': 'TestPass123!',
            'app_name': 'e-declaration'
        }
        response_initiate = client.post('/auth/initiate-2fa',
                                       data=json.dumps(payload_initiate),
                                       content_type='application/json')
        
        assert response_initiate.status_code == 200
        data_initiate = json.loads(response_initiate.data)
        session_id = data_initiate['session_id']
        
        # In real test, we would read OTP from email
        # For now, we need to mock it by reading from _otp_sessions
        # This requires accessing the app context
        
        print(f"Session ID: {session_id}")
        print(f"OTP should have been sent to: {data_initiate['message']}")
    
    def test_verify_session(self, client):
        """Test session verification endpoint"""
        # First, create a 2FA session and get session token
        # This would need mock session data
        pass