# tests/conftest.py
"""Pytest Configuration and Fixtures"""

import pytest
import sys
import os

# Add parent directory to path so we can import backend
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.app import create_app
from backend.config import TestingConfig

@pytest.fixture(scope='session')
def app():
    """Create application for testing"""
    app = create_app(TestingConfig)
    return app

@pytest.fixture(scope='function')
def client(app):
    """Create test client"""
    return app.test_client()

@pytest.fixture(scope='function')
def app_context(app):
    """Create application context"""
    with app.app_context():
        yield app