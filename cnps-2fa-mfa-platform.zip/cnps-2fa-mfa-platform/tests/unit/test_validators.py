# tests/unit/test_validators.py
"""Unit Tests for Validators"""

import pytest
from backend.utils.validators import (
    validate_username,
    validate_password,
    validate_email,
    validate_app_name,
    validate_otp_code
)

class TestValidators:
    """Test input validators"""
    
    def test_validate_username_valid(self):
        """Test valid username"""
        is_valid, error = validate_username('testuser')
        assert is_valid == True
        assert error is None
    
    def test_validate_username_too_short(self):
        """Test username too short"""
        is_valid, error = validate_username('ab')
        assert is_valid == False
        assert error is not None
    
    def test_validate_username_invalid_chars(self):
        """Test username with invalid characters"""
        is_valid, error = validate_username('test@user!')
        assert is_valid == False
    
    def test_validate_password_valid(self):
        """Test valid password"""
        is_valid, error = validate_password('MyPassword123')
        assert is_valid == True
    
    def test_validate_password_empty(self):
        """Test empty password"""
        is_valid, error = validate_password('')
        assert is_valid == False
    
    def test_validate_email_valid(self):
        """Test valid email"""
        is_valid, error = validate_email('user@cnps.cm')
        assert is_valid == True
    
    def test_validate_email_invalid(self):
        """Test invalid email"""
        is_valid, error = validate_email('invalid-email')
        assert is_valid == False
    
    def test_validate_app_name_valid(self):
        """Test valid app name"""
        is_valid, error = validate_app_name('e-declaration')
        assert is_valid == True
    
    def test_validate_otp_code_valid(self):
        """Test valid OTP code"""
        is_valid, error = validate_otp_code('ABC1')
        assert is_valid == True
    
    def test_validate_otp_code_invalid_length(self):
        """Test OTP code with wrong length"""
        is_valid, error = validate_otp_code('AB')
        assert is_valid == False