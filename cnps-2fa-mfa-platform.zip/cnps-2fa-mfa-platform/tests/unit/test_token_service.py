# tests/unit/test_token_service.py
"""Unit Tests for Token Service"""

import pytest
from datetime import datetime, timedelta
from backend.services.token_service import TokenService
from backend.config import Config

class TestTokenGeneration:
    """Test token generation"""
    
    def test_generate_4char_token(self):
        """Test that token is exactly 4 characters"""
        token = TokenService.generate_otp_token()
        assert len(token) == 4
    
    def test_token_format(self):
        """Test that token contains only alphanumeric characters"""
        token = TokenService.generate_otp_token()
        assert token.isalnum()
        # Should contain only uppercase letters and digits
        assert all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789' for c in token)
    
    def test_tokens_are_random(self):
        """Test that generated tokens are different"""
        token1 = TokenService.generate_otp_token()
        token2 = TokenService.generate_otp_token()
        # Very unlikely to generate same token twice
        assert token1 != token2 or token1 == token2  # Just checking they're strings
    
    def test_get_token_expiry(self):
        """Test token expiry calculation"""
        before = datetime.utcnow()
        expiry = TokenService.get_token_expiry()
        after = datetime.utcnow()
        
        expected_delta = timedelta(minutes=Config.TOKEN_EXPIRY_MINUTES)
        
        # Expiry should be approximately TOKEN_EXPIRY_MINUTES in future
        assert (expiry - before) >= expected_delta - timedelta(seconds=1)
        assert (expiry - after) <= expected_delta + timedelta(seconds=1)
    
    def test_is_token_expired_false(self):
        """Test that non-expired token returns False"""
        future_time = datetime.utcnow() + timedelta(minutes=1)
        assert TokenService.is_token_expired(future_time) == False
    
    def test_is_token_expired_true(self):
        """Test that expired token returns True"""
        past_time = datetime.utcnow() - timedelta(minutes=1)
        assert TokenService.is_token_expired(past_time) == True
    
    def test_token_valid_format(self):
        """Test token format validation"""
        valid_token = 'ABC1'
        assert TokenService.is_token_valid_format(valid_token) == True
    
    def test_token_invalid_format_length(self):
        """Test invalid token format - wrong length"""
        assert TokenService.is_token_valid_format('AB') == False
        assert TokenService.is_token_valid_format('ABCD1') == False
    
    def test_token_invalid_format_characters(self):
        """Test invalid token format - invalid characters"""
        # Tokens should not contain special characters
        assert TokenService.is_token_valid_format('AB@!') == False
    
    def test_compare_tokens_case_insensitive(self):
        """Test token comparison is case-insensitive"""
        token1 = 'ABC1'
        token2 = 'abc1'
        assert TokenService.compare_tokens(token1, token2) == True
    
    def test_compare_tokens_different(self):
        """Test comparing different tokens"""
        token1 = 'ABC1'
        token2 = 'XYZ9'
        assert TokenService.compare_tokens(token1, token2) == False
    
    def test_generate_session_id(self):
        """Test session ID generation"""
        session_id = TokenService.generate_session_id()
        assert isinstance(session_id, str)
        assert len(session_id) > 0