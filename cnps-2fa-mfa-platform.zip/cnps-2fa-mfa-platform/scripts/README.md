# CNPS 2FA MFA Authentication Platform

Multi-Factor Authentication (2FA) platform for CNPS Cameroon using email-based One-Time Password (OTP).

## 📋 Project Overview

This project implements a central authentication gateway that provides:
- **Step 1**: Username & Password validation against Active Directory
- **Step 2**: Generation of 4-character OTP token
- **Step 3**: Email delivery via Zimbra SMTP
- **Step 4**: Token validation and session management
- **Audit logging** for compliance and security investigation

## 🏗️ Architecture
