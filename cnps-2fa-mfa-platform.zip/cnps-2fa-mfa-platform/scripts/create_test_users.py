# scripts/create_test_users.py
"""Create Test Users for Local Testing"""

from backend.services.ad_connector import MockADConnector

def create_test_users():
    """Display test users available for testing"""
    print("=" * 60)
    print("CNPS 2FA - Test Users for Local Development")
    print("=" * 60)
    
    print("\nAvailable test users (MockADConnector):\n")
    
    for username, user_info in MockADConnector.TEST_USERS.items():
        print(f"Username: {username}")
        print(f"  Password: {user_info['password']}")
        print(f"  Email: {user_info['email']}")
        print(f"  Full Name: {user_info['full_name']}")
        print()
    
    print("=" * 60)
    print("\nUsage:")
    print("POST /auth/initiate-2fa")
    print('{"username": "testuser1", "password": "TestPass123!", "app_name": "e-declaration"}')
    print("\n" + "=" * 60)

if __name__ == '__main__':
    create_test_users()