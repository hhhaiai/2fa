# scripts/setup_db.py
"""Database Setup Script"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.app import create_app

def setup_database():
    """Initialize database with tables"""
    app = create_app()
    
    with app.app_context():
        print("=" * 60)
        print("CNPS 2FA - Database Setup")
        print("=" * 60)
        
        # Note: In production, use SQLAlchemy ORM with migrations (Alembic)
        # For now, we're using in-memory storage in services
        
        print("✓ Database configuration loaded")
        print(f"  Database URL: {app.config['SQLALCHEMY_DATABASE_URI']}")
        
        print("\n✓ In this version, models use in-memory storage")
        print("  In production, migrate to PostgreSQL with SQLAlchemy")
        
        print("\n✓ Setup complete!")
        print("=" * 60)

if __name__ == '__main__':
    setup_database()