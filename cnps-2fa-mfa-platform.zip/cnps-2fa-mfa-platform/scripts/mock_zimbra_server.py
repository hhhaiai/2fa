# scripts/mock_zimbra_server.py
"""Monitor Mock Zimbra Email Output"""

import os
import time
import json
from pathlib import Path

def monitor_mock_emails():
    """Monitor and display emails sent via MockEmailService"""
    print("=" * 60)
    print("CNPS 2FA - Mock Zimbra Email Monitor")
    print("=" * 60)
    print("Watching for OTP emails... (Ctrl+C to exit)\n")
    
    email_file = 'test_emails.log'
    last_position = 0
    
    try:
        while True:
            if os.path.exists(email_file):
                with open(email_file, 'r') as f:
                    f.seek(last_position)
                    new_lines = f.readlines()
                    last_position = f.tell()
                    
                    for line in new_lines:
                        if line.strip():
                            try:
                                email_data = json.loads(line)
                                print(f"\n{'='*60}")
                                print(f"📧 NEW EMAIL")
                                print(f"{'='*60}")
                                print(f"To: {email_data['to']}")
                                print(f"Username: {email_data['username']}")
                                print(f"Token: {email_data['token']}")
                                print(f"Sent At: {email_data['sent_at']}")
                                print(f"{'='*60}\n")
                            except json.JSONDecodeError:
                                pass
            
            time.sleep(1)
    
    except KeyboardInterrupt:
        print("\nMonitoring stopped")

if __name__ == '__main__':
    monitor_mock_emails()