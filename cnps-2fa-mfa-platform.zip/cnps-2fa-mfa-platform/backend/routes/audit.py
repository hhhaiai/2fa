# backend/routes/audit.py
"""Audit Logging Routes"""

from flask import Blueprint, request, jsonify
import logging

from backend.services.audit_service import AuditService

logger = logging.getLogger(__name__)

audit_bp = Blueprint('audit', __name__, url_prefix='/audit')


@audit_bp.route('/logs', methods=['GET'])
def get_audit_logs():
    """
    Retrieve audit logs (for compliance and investigation)
    
    Query parameters:
    - username: Filter by username
    - action: Filter by action
    - app_name: Filter by application name
    - limit: Maximum number of logs (default: 100)
    
    Returns:
        JSON: List of audit log records
    """
    try:
        # Get query parameters
        username = request.args.get('username')
        action = request.args.get('action')
        app_name = request.args.get('app_name')
        limit = request.args.get('limit', 100, type=int)
        
        logger.info(f"[AUDIT] Retrieving logs - User: {username}, Action: {action}, App: {app_name}")
        
        # Get filtered logs
        logs = AuditService.get_logs(
            username=username,
            action=action,
            app_name=app_name,
            limit=limit
        )
        
        return jsonify({
            'status': 'success',
            'count': len(logs),
            'logs': logs
        }), 200
    
    except Exception as e:
        logger.error(f"[AUDIT] Error retrieving logs: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred while retrieving logs'
        }), 500


@audit_bp.route('/logs/user/<username>', methods=['GET'])
def get_user_logs(username):
    """
    Retrieve audit logs for a specific user
    
    Returns:
        JSON: List of audit log records for the user
    """
    try:
        logger.info(f"[AUDIT] Retrieving logs for user: {username}")
        
        logs = AuditService.get_logs(username=username)
        
        return jsonify({
            'status': 'success',
            'username': username,
            'count': len(logs),
            'logs': logs
        }), 200
    
    except Exception as e:
        logger.error(f"[AUDIT] Error retrieving user logs: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred'
        }), 500


@audit_bp.route('/logs/export', methods=['GET'])
def export_logs():
    """
    Export audit logs (for compliance reporting)
    
    Query parameters:
    - format: Export format ('json' or 'csv')
    
    Returns:
        File: Exported logs
    """
    try:
        format_type = request.args.get('format', 'json')
        
        if format_type not in ['json', 'csv']:
            return jsonify({
                'status': 'error',
                'message': 'Invalid format. Use json or csv'
            }), 400
        
        logs_data = AuditService.export_logs(format=format_type)
        
        return logs_data, 200, {
            'Content-Type': 'application/json' if format_type == 'json' else 'text/csv',
            'Content-Disposition': f'attachment; filename=audit-logs.{format_type}'
        }
    
    except Exception as e:
        logger.error(f"[AUDIT] Error exporting logs: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred while exporting logs'
        }), 500