# backend/routes/health.py
"""Health Check Routes"""

from flask import Blueprint, jsonify
import logging

logger = logging.getLogger(__name__)

health_bp = Blueprint('health', __name__, url_prefix='/health')

@health_bp.route('', methods=['GET'])
def health_check():
    """
    Health check endpoint
    
    Returns:
        JSON: Status and service information
    """
    return jsonify({
        'status': 'healthy',
        'service': 'CNPS 2FA MFA Platform',
        'version': '1.0.0',
        'message': 'Service is running'
    }), 200


@health_bp.route('/ready', methods=['GET'])
def readiness_check():
    """
    Readiness check endpoint - checks if service is ready to handle requests
    
    Returns:
        JSON: Readiness status
    """
    # In production, check database connectivity, etc.
    return jsonify({
        'status': 'ready',
        'message': 'Service is ready'
    }), 200


@health_bp.route('/live', methods=['GET'])
def liveness_check():
    """
    Liveness check endpoint - checks if service is alive
    
    Returns:
        JSON: Liveness status
    """
    return jsonify({
        'status': 'alive',
        'message': 'Service is alive'
    }), 200