# backend/routes/auth.py
"""Authentication Routes"""

from flask import Blueprint, request, jsonify, current_app
from datetime import datetime
import logging

from backend.services.ad_connector import MockADConnector, ADConnector
from backend.services.token_service import TokenService
from backend.services.email_service import EmailService
from backend.services.session_service import SessionService
from backend.services.audit_service import AuditService
from backend.utils.validators import (
    validate_username, 
    validate_password, 
    validate_app_name, 
    validate_otp_code
)
from backend.utils.constants import *

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

# Choose connector based on environment
USE_MOCK_AD = True  # Set to False when real AD is available
ad_connector = MockADConnector() if USE_MOCK_AD else ADConnector()

# In-memory storage for OTP tokens and sessions (use database in production)
_otp_sessions = {}


@auth_bp.route('/initiate-2fa', methods=['POST'])
def initiate_2fa():
    """
    Step 1 of 2FA: User enters username and password
    
    If valid, system generates OTP and sends via email
    
    Request body:
    {
        "username": "testuser1",
        "password": "TestPass123!",
        "app_name": "e-declaration"
    }
    
    Response:
    {
        "status": "pending_otp",
        "session_id": "uuid",
        "message": "OTP sent to testuser1@cnps.cm"
    }
    """
    try:
        # Get request data
        data = request.get_json()
        
        if not data:
            return jsonify({
                'status': 'error',
                'message': 'Request body is required'
            }), 400
        
        username = data.get('username', '').strip()
        password = data.get('password', '')
        app_name = data.get('app_name', '').strip()
        
        # Validate inputs
        is_valid_user, user_error = validate_username(username)
        if not is_valid_user:
            AuditService.log_action(
                username=username,
                action=ACTION_LOGIN_FAILED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason=f'Invalid username format: {user_error}',
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': user_error
            }), 400
        
        is_valid_pass, pass_error = validate_password(password)
        if not is_valid_pass:
            AuditService.log_action(
                username=username,
                action=ACTION_LOGIN_FAILED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason='Password is required',
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': pass_error
            }), 400
        
        is_valid_app, app_error = validate_app_name(app_name)
        if not is_valid_app:
            return jsonify({
                'status': 'error',
                'message': app_error
            }), 400
        
        logger.info(f"[AUTH] 2FA initiation request from {username} for app: {app_name}")
        
        # ===== STEP 1: Validate against Active Directory =====
        user_info = ad_connector.validate_credentials(username, password)
        
        if not user_info:
            logger.warning(f"[AUTH] ✗ Invalid credentials for: {username}")
            AuditService.log_action(
                username=username,
                action=ACTION_LOGIN_FAILED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason=ERROR_INVALID_CREDENTIALS,
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': ERROR_INVALID_CREDENTIALS
            }), 401
        
        logger.info(f"[AUTH] ✓ AD validation successful for: {username}")
        
        # ===== STEP 2: Generate OTP Token =====
        otp_token = TokenService.generate_otp_token()
        token_expires_at = TokenService.get_token_expiry()
        session_id = TokenService.generate_session_id()
        
        logger.info(f"[AUTH] Generated OTP token for {username}: {otp_token}")
        
        # Store OTP session
        _otp_sessions[session_id] = {
            'username': username,
            'email': user_info['email'],
            'otp_token': otp_token,
            'app_name': app_name,
            'expires_at': token_expires_at,
            'failed_attempts': 0,
            'is_valid': True,
            'created_at': datetime.utcnow()
        }
        
        # ===== STEP 3: Send OTP via Email =====
        email_sent = EmailService.send_otp(
            email=user_info['email'],
            token=otp_token,
            username=username
        )
        
        if not email_sent:
            logger.error(f"[AUTH] Failed to send OTP to {user_info['email']}")
            AuditService.log_action(
                username=username,
                action=ACTION_TOKEN_GENERATED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason=ERROR_EMAIL_SEND,
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': ERROR_EMAIL_SEND
            }), 500
        
        logger.info(f"[AUTH] ✓ OTP sent to {user_info['email']}")
        
        # ===== STEP 4: Audit Logging =====
        AuditService.log_action(
            username=username,
            action=ACTION_TOKEN_GENERATED,
            app_name=app_name,
            status=STATUS_SUCCESS,
            ip_address=request.remote_addr
        )
        
        return jsonify({
            'status': 'pending_otp',
            'session_id': session_id,
            'message': f'OTP sent to {user_info["email"]}',
            'expires_in_seconds': current_app.config['TOKEN_EXPIRY_MINUTES'] * 60
        }), 200
    
    except Exception as e:
        logger.error(f"[AUTH] Error in initiate_2fa: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred'
        }), 500


@auth_bp.route('/validate-otp', methods=['POST'])
def validate_otp():
    """
    Step 2 of 2FA: User enters OTP code received via email
    
    If valid, system issues a session token for access
    
    Request body:
    {
        "session_id": "uuid",
        "otp_code": "ABC1"
    }
    
    Response:
    {
        "status": "success",
        "session_token": "long-token-string",
        "expires_at": "2026-03-06T15:30:00Z"
    }
    """
    try:
        # Get request data
        data = request.get_json()
        
        if not data:
            return jsonify({
                'status': 'error',
                'message': 'Request body is required'
            }), 400
        
        session_id = data.get('session_id', '').strip()
        otp_code = data.get('otp_code', '').strip()
        
        # Validate OTP code format
        is_valid_otp, otp_error = validate_otp_code(otp_code)
        if not is_valid_otp:
            return jsonify({
                'status': 'error',
                'message': otp_error
            }), 400
        
        logger.info(f"[AUTH] OTP validation request for session: {session_id}")
        
        # ===== STEP 1: Retrieve OTP Session =====
        otp_session = _otp_sessions.get(session_id)
        
        if not otp_session:
            logger.warning(f"[AUTH] ✗ Session not found: {session_id}")
            return jsonify({
                'status': 'error',
                'message': 'Invalid or expired session'
            }), 401
        
        username = otp_session['username']
        app_name = otp_session['app_name']
        
        # ===== STEP 2: Check if Token is Expired =====
        if TokenService.is_token_expired(otp_session['expires_at']):
            logger.warning(f"[AUTH] ✗ Token expired for {username}")
            otp_session['is_valid'] = False
            AuditService.log_action(
                username=username,
                action=ACTION_LOGIN_FAILED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason=ERROR_TOKEN_EXPIRED,
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': ERROR_TOKEN_EXPIRED
            }), 401
        
        # ===== STEP 3: Check Max Attempts =====
        if otp_session['failed_attempts'] >= current_app.config['MAX_TOKEN_ATTEMPTS']:
            logger.warning(f"[AUTH] ✗ Max attempts exceeded for {username}")
            otp_session['is_valid'] = False
            AuditService.log_action(
                username=username,
                action=ACTION_LOGIN_FAILED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason=ERROR_MAX_ATTEMPTS,
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': ERROR_MAX_ATTEMPTS
            }), 401
        
        # ===== STEP 4: Validate OTP Code =====
        if not TokenService.compare_tokens(otp_code, otp_session['otp_token']):
            logger.warning(f"[AUTH] ✗ Invalid OTP code for {username}")
            otp_session['failed_attempts'] += 1
            AuditService.log_action(
                username=username,
                action=ACTION_LOGIN_FAILED,
                app_name=app_name,
                status=STATUS_FAILURE,
                reason=ERROR_INVALID_TOKEN,
                ip_address=request.remote_addr
            )
            return jsonify({
                'status': 'error',
                'message': ERROR_INVALID_TOKEN,
                'attempts_remaining': current_app.config['MAX_TOKEN_ATTEMPTS'] - otp_session['failed_attempts']
            }), 401
        
        logger.info(f"[AUTH] ✓ OTP validated successfully for {username}")
        
        # ===== STEP 5: Create Session Token =====
        session_info = SessionService.create_session_token(username, app_name)
        
        logger.info(f"[AUTH] ✓ Session token created for {username}")
        
        # ===== STEP 6: Audit Logging =====
        AuditService.log_action(
            username=username,
            action=ACTION_LOGIN_SUCCESS,
            app_name=app_name,
            status=STATUS_SUCCESS,
            ip_address=request.remote_addr
        )
        
        # Mark OTP session as used
        otp_session['is_valid'] = False
        
        return jsonify({
            'status': 'success',
            'message': 'Login successful',
            'session_token': session_info['session_token'],
            'session_id': session_info['session_id'],
            'username': session_info['username'],
            'app_name': session_info['app_name'],
            'expires_at': session_info['expires_at']
        }), 200
    
    except Exception as e:
        logger.error(f"[AUTH] Error in validate_otp: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred'
        }), 500


@auth_bp.route('/verify-session', methods=['POST'])
def verify_session():
    """
    Verify an existing session token
    
    Used by applications to verify that a session token is still valid
    
    Request body:
    {
        "session_id": "uuid",
        "session_token": "long-token-string"
    }
    
    Response:
    {
        "status": "valid",
        "username": "testuser1",
        "app_name": "e-declaration",
        "expires_at": "2026-03-06T15:30:00Z"
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'status': 'error',
                'message': 'Request body is required'
            }), 400
        
        session_id = data.get('session_id', '').strip()
        session_token = data.get('session_token', '').strip()
        
        if not session_id or not session_token:
            return jsonify({
                'status': 'error',
                'message': 'session_id and session_token are required'
            }), 400
        
        logger.info(f"[AUTH] Session verification request for: {session_id}")
        
        # Validate session token
        session_info = SessionService.validate_session_token(session_id, session_token)
        
        if not session_info:
            logger.warning(f"[AUTH] ✗ Invalid session: {session_id}")
            return jsonify({
                'status': 'error',
                'message': 'Invalid or expired session token'
            }), 401
        
        logger.info(f"[AUTH] ✓ Session verified for {session_info['username']}")
        
        return jsonify({
            'status': 'valid',
            'message': 'Session is valid',
            'username': session_info['username'],
            'app_name': session_info['app_name'],
            'expires_at': session_info['expires_at'].isoformat()
        }), 200
    
    except Exception as e:
        logger.error(f"[AUTH] Error in verify_session: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred'
        }), 500


@auth_bp.route('/revoke-session', methods=['POST'])
def revoke_session():
    """
    Revoke/logout a session
    
    Request body:
    {
        "session_id": "uuid"
    }
    
    Response:
    {
        "status": "success",
        "message": "Session revoked"
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'status': 'error',
                'message': 'Request body is required'
            }), 400
        
        session_id = data.get('session_id', '').strip()
        
        if not session_id:
            return jsonify({
                'status': 'error',
                'message': 'session_id is required'
            }), 400
        
        success = SessionService.revoke_session(session_id)
        
        if not success:
            return jsonify({
                'status': 'error',
                'message': 'Session not found'
            }), 404
        
        return jsonify({
            'status': 'success',
            'message': 'Session revoked'
        }), 200
    
    except Exception as e:
        logger.error(f"[AUTH] Error in revoke_session: {str(e)}", exc_info=True)
        return jsonify({
            'status': 'error',
            'message': 'An error occurred'
        }), 500