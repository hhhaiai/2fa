# backend/routes/__init__.py
"""Routes Package"""

from backend.routes.auth import auth_bp
from backend.routes.health import health_bp
from backend.routes.audit import audit_bp

__all__ = ['auth_bp', 'health_bp', 'audit_bp']