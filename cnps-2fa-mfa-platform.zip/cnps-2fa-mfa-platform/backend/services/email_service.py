# backend/services/email_service.py
"""Email Service - Handles sending OTP codes"""

import logging
import json
from datetime import datetime
from flask import current_app

logger = logging.getLogger(__name__)

class MockEmailService:
    """Mock email service for testing (logs emails instead of sending)"""
    
    @staticmethod
    def send_otp(email, token, username):
        """
        Simulate sending OTP via email (logs to file for testing)
        
        Args:
            email (str): Recipient email
            token (str): OTP token
            username (str): Username
            
        Returns:
            bool: True if successful
        """
        try:
            email_record = {
                'to': email,
                'username': username,
                'token': token,
                'subject': 'CNPS Authentication Code',
                'body': f'Your CNPS authentication code is: {token}\n\nThis code expires in 5 minutes.\n\nIf you did not request this, please contact support.',
                'sent_at': datetime.utcnow().isoformat(),
            }
            
            # Write to test_emails.log for inspection
            with open('test_emails.log', 'a') as f:
                f.write(json.dumps(email_record) + '\n')
            
            logger.info(f"[MOCK EMAIL] ✉️  OTP sent to {email} | Token: {token}")
            print(f"\n{'='*60}")
            print(f"✉️  [MOCK EMAIL] OTP CODE: {token}")
            print(f"   Sent to: {email}")
            print(f"   Username: {username}")
            print(f"   Expires in: 5 minutes")
            print(f"{'='*60}\n")
            
            return True
            
        except Exception as e:
            logger.error(f"[MOCK EMAIL] Failed to send OTP: {str(e)}")
            return False


class RealEmailService:
    """Real email service using SMTP (Zimbra)"""
    
    @staticmethod
    def send_otp(email, token, username):
        """
        Send OTP via real SMTP server (Zimbra)
        
        Args:
            email (str): Recipient email
            token (str): OTP token
            username (str): Username
            
        Returns:
            bool: True if successful
        """
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart
            
            # Get Zimbra config
            mail_server = current_app.config['MAIL_SERVER']
            mail_port = current_app.config['MAIL_PORT']
            mail_username = current_app.config['MAIL_USERNAME']
            mail_password = current_app.config['MAIL_PASSWORD']
            mail_from = current_app.config['EMAIL_FROM']
            
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = 'CNPS Authentication Code'
            msg['From'] = mail_from
            msg['To'] = email
            
            # Email body
            text = f"""Your CNPS authentication code is: {token}

This code expires in 5 minutes.

If you did not request this, please contact support immediately.

Do not share this code with anyone.
"""
            
            part = MIMEText(text, 'plain')
            msg.attach(part)
            
            # Send email
            with smtplib.SMTP(mail_server, mail_port) as server:
                if current_app.config.get('MAIL_USE_TLS'):
                    server.starttls()
                if mail_username and mail_password:
                    server.login(mail_username, mail_password)
                server.send_message(msg)
            
            logger.info(f"✓ OTP sent to {email} via Zimbra")
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to send OTP via Zimbra: {str(e)}")
            return False


class EmailService:
    """Email service factory - uses mock or real based on config"""
    
    @staticmethod
    def send_otp(email, token, username):
        """
        Send OTP email using configured provider
        
        Args:
            email (str): Recipient email
            token (str): OTP token
            username (str): Username
            
        Returns:
            bool: True if successful
        """
        provider = current_app.config.get('EMAIL_PROVIDER', 'mock')
        
        if provider == 'mock':
            return MockEmailService.send_otp(email, token, username)
        else:
            return RealEmailService.send_otp(email, token, username)