# backend/services/token_service.py
"""Token Generation and Validation Service"""

from datetime import datetime, timedelta
from backend.utils.encryption import generate_4char_token, generate_session_id
from backend.config import Config

class TokenService:
    """Service for generating and validating OTP tokens"""
    
    @staticmethod
    def generate_otp_token():
        """
        Generate a 4-character OTP token
        
        Returns:
            str: 4-character token
        """
        return generate_4char_token()
    
    @staticmethod
    def get_token_expiry():
        """
        Calculate token expiry time
        
        Returns:
            datetime: Token expiry datetime
        """
        return datetime.utcnow() + timedelta(minutes=Config.TOKEN_EXPIRY_MINUTES)
    
    @staticmethod
    def is_token_expired(expires_at):
        """
        Check if token has expired
        
        Args:
            expires_at (datetime): Token expiry time
            
        Returns:
            bool: True if expired, False otherwise
        """
        return datetime.utcnow() > expires_at
    
    @staticmethod
    def is_token_valid_format(token):
        """
        Validate token format (should be 4 alphanumeric chars)
        
        Args:
            token (str): Token to validate
            
        Returns:
            bool: True if valid format, False otherwise
        """
        if not token or len(token) != 4:
            return False
        return token.upper().isalnum()
    
    @staticmethod
    def generate_session_id():
        """
        Generate a unique session ID
        
        Returns:
            str: Unique session ID
        """
        return generate_session_id()
    
    @staticmethod
    def compare_tokens(token1, token2):
        """
        Compare two tokens (case-insensitive)
        
        Args:
            token1 (str): First token
            token2 (str): Second token
            
        Returns:
            bool: True if tokens match, False otherwise
        """
        return token1.upper() == token2.upper()