# backend/services/session_service.py
"""Session Management Service"""

import logging
from datetime import datetime, timedelta
from backend.utils.encryption import generate_session_token, hash_token, generate_uuid
from backend.config import Config

logger = logging.getLogger(__name__)

class SessionService:
    """Service for managing user sessions"""
    
    # In-memory session store (in production, use database)
    _sessions = {}
    
    @staticmethod
    def create_session_token(username, app_name):
        """
        Create a new session token after successful 2FA
        
        Args:
            username (str): Username
            app_name (str): Application name
            
        Returns:
            dict: Session info including token
        """
        session_id = generate_uuid()
        token = generate_session_token()
        expires_at = datetime.utcnow() + timedelta(hours=Config.SESSION_TIMEOUT_HOURS)
        
        session_data = {
            'session_id': session_id,
            'username': username,
            'app_name': app_name,
            'token': token,
            'token_hash': hash_token(token),
            'is_active': True,
            'created_at': datetime.utcnow(),
            'expires_at': expires_at,
            'last_activity': datetime.utcnow(),
        }
        
        SessionService._sessions[session_id] = session_data
        
        logger.info(f"✓ Session created for: {username} (App: {app_name})")
        
        return {
            'session_id': session_id,
            'session_token': token,
            'username': username,
            'app_name': app_name,
            'expires_at': expires_at.isoformat(),
        }
    
    @staticmethod
    def validate_session_token(session_id, token):
        """
        Validate a session token
        
        Args:
            session_id (str): Session ID
            token (str): Session token
            
        Returns:
            dict: User info if valid, None if invalid
        """
        session = SessionService._sessions.get(session_id)
        
        if not session:
            logger.warning(f"✗ Session not found: {session_id}")
            return None
        
        # Check if active
        if not session['is_active']:
            logger.warning(f"✗ Session inactive: {session_id}")
            return None
        
        # Check if expired
        if datetime.utcnow() > session['expires_at']:
            session['is_active'] = False
            logger.warning(f"✗ Session expired: {session_id}")
            return None
        
        # Verify token
        if hash_token(token) != session['token_hash']:
            logger.warning(f"✗ Invalid token for session: {session_id}")
            return None
        
        # Update last activity
        session['last_activity'] = datetime.utcnow()
        
        logger.info(f"✓ Session validated for: {session['username']}")
        
        return {
            'session_id': session_id,
            'username': session['username'],
            'app_name': session['app_name'],
            'created_at': session['created_at'],
            'expires_at': session['expires_at'],
        }
    
    @staticmethod
    def revoke_session(session_id):
        """
        Revoke a session
        
        Args:
            session_id (str): Session ID
            
        Returns:
            bool: True if successful
        """
        session = SessionService._sessions.get(session_id)
        
        if session:
            session['is_active'] = False
            logger.info(f"✓ Session revoked: {session_id}")
            return True
        
        return False
    
    @staticmethod
    def get_session_info(session_id):
        """
        Get session information
        
        Args:
            session_id (str): Session ID
            
        Returns:
            dict: Session info
        """
        return SessionService._sessions.get(session_id)