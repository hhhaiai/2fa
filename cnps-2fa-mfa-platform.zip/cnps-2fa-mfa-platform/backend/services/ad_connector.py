# backend/services/ad_connector.py
"""Active Directory Connector Service"""

from ldap3 import Server, Connection, ALL, NTLM
from ldap3.utils.conv import escape_filter_chars
from flask import current_app
import logging

logger = logging.getLogger(__name__)


class MockADConnector:
    """Mock Active Directory connector for testing (no real AD needed)"""

    TEST_USERS = {
        'testuser1': {
            'password': 'TestPass123!',
            'email': 'testuser1@cnps.cm',
            'full_name': 'Test User One',
            'active': True
        },
        'testuser2': {
            'password': 'TestPass456!',
            'email': 'testuser2@cnps.cm',
            'full_name': 'Test User Two',
            'active': True
        },
        'admin': {
            'password': 'Admin123!',
            'email': 'admin@cnps.cm',
            'full_name': 'Administrator',
            'active': True
        }
    }

    @staticmethod
    def validate_credentials(username, password):
        logger.info(f"[MOCK AD] Validating credentials for: {username}")

        user = MockADConnector.TEST_USERS.get(username)

        if user and user['password'] == password and user['active']:
            logger.info(f"[MOCK AD] ✓ Authentication successful for: {username}")

            return {
                'username': username,
                'email': user['email'],
                'full_name': user['full_name'],
                'active': user['active']
            }

        logger.warning(f"[MOCK AD] ✗ Authentication failed for: {username}")
        return None

    @staticmethod
    def get_user_email(username):
        user = MockADConnector.TEST_USERS.get(username)
        return user['email'] if user else None


class ADConnector:
    """Real Active Directory connector using ldap3"""

    def __init__(self):
        self.server = current_app.config['AD_SERVER']
        self.domain = current_app.config['AD_DOMAIN']
        self.base_dn = current_app.config['AD_BASE_DN']
        self.admin_username = current_app.config['AD_USERNAME']
        self.admin_password = current_app.config['AD_PASSWORD']

    def validate_credentials(self, username, password):

        try:
            logger.info(f"[AD] Validating credentials for: {username}")

            server = Server(self.server, get_info=ALL)

            user = f"{self.domain}\\{username}"

            conn = Connection(
                server,
                user=user,
                password=password,
                authentication=NTLM,
                auto_bind=True
            )

            safe_username = escape_filter_chars(username)

            search_filter = f"(sAMAccountName={safe_username})"

            conn.search(
                self.base_dn,
                search_filter,
                attributes=["mail", "displayName"]
            )

            if conn.entries:

                entry = conn.entries[0]

                email = str(entry.mail) if entry.mail else ""
                full_name = str(entry.displayName) if entry.displayName else ""

                logger.info(f"[AD] ✓ Authentication successful for: {username}")

                conn.unbind()

                return {
                    "username": username,
                    "email": email,
                    "full_name": full_name,
                    "active": True
                }

            logger.warning(f"[AD] ✗ User not found in directory: {username}")

            conn.unbind()
            return None

        except Exception as e:
            logger.error(f"[AD] Error validating credentials: {str(e)}")
            return None

    def get_user_email(self, username):

        try:

            server = Server(self.server, get_info=ALL)

            conn = Connection(
                server,
                user=self.admin_username,
                password=self.admin_password,
                auto_bind=True
            )

            safe_username = escape_filter_chars(username)

            search_filter = f"(sAMAccountName={safe_username})"

            conn.search(
                self.base_dn,
                search_filter,
                attributes=["mail"]
            )

            if conn.entries:
                email = str(conn.entries[0].mail)
                conn.unbind()
                return email

            conn.unbind()
            return None

        except Exception as e:
            logger.error(f"[AD] Error retrieving email: {str(e)}")
            return None