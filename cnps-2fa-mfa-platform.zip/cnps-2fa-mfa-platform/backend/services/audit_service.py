# backend/services/audit_service.py
"""Audit Logging Service"""

import logging
from datetime import datetime
from backend.utils.encryption import generate_uuid

logger = logging.getLogger(__name__)

class AuditService:
    """Service for audit logging"""
    
    # In-memory audit log (in production, use database)
    _audit_logs = []
    
    @staticmethod
    def log_action(username, action, app_name, status='success', reason=None, ip_address=None, user_agent=None):
        """
        Log an audit action
        
        Args:
            username (str): Username
            action (str): Action (e.g., 'token_generated', 'login_success')
            app_name (str): Application name
            status (str): 'success' or 'failure'
            reason (str): Reason for failure, if any
            ip_address (str): User's IP address
            user_agent (str): User's user agent
            
        Returns:
            str: Audit log ID
        """
        log_id = generate_uuid()
        
        audit_record = {
            'id': log_id,
            'username': username,
            'action': action,
            'app_name': app_name,
            'status': status,
            'reason': reason,
            'ip_address': ip_address,
            'user_agent': user_agent,
            'timestamp': datetime.utcnow().isoformat(),
        }
        
        AuditService._audit_logs.append(audit_record)
        
        # Also log to application logger
        log_level = logging.INFO if status == 'success' else logging.WARNING
        logger.log(
            log_level,
            f"[AUDIT] {action} | User: {username} | App: {app_name} | Status: {status}"
        )
        
        return log_id
    
    @staticmethod
    def get_logs(username=None, action=None, app_name=None, limit=100):
        """
        Retrieve audit logs with optional filtering
        
        Args:
            username (str): Filter by username
            action (str): Filter by action
            app_name (str): Filter by application
            limit (int): Maximum number of logs to return
            
        Returns:
            list: Audit log records
        """
        logs = AuditService._audit_logs
        
        # Apply filters
        if username:
            logs = [log for log in logs if log['username'] == username]
        if action:
            logs = [log for log in logs if log['action'] == action]
        if app_name:
            logs = [log for log in logs if log['app_name'] == app_name]
        
        # Return most recent logs first, limit results
        return sorted(logs, key=lambda x: x['timestamp'], reverse=True)[:limit]
    
    @staticmethod
    def export_logs(format='json'):
        """
        Export audit logs for compliance/audit
        
        Args:
            format (str): Export format ('json', 'csv', etc.)
            
        Returns:
            str: Formatted logs
        """
        import json
        if format == 'json':
            return json.dumps(AuditService._audit_logs, indent=2, default=str)
        return str(AuditService._audit_logs)