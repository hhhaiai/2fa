# backend/app.py
"""Flask Application Factory"""

from flask import Flask
from flask_cors import CORS
import logging
import os

from backend.config import get_config
from backend.routes import auth_bp, health_bp, audit_bp
from backend.middleware import setup_error_handlers, setup_logging, setup_rate_limiter

logger = logging.getLogger(__name__)

def create_app(config=None):
    """
    Create and configure Flask application
    
    Args:
        config: Configuration object (uses environment if not provided)
        
    Returns:
        Flask: Configured Flask application
    """
    
    # Create Flask app
    app = Flask(__name__)
    
    # Load configuration
    if config is None:
        config = get_config()
    app.config.from_object(config)
    
    # Setup logging
    setup_logging(app)
    app.logger.info("Logging initialized")
    
    # Enable CORS
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    app.logger.info("CORS enabled")
    
    # Setup error handlers
    setup_error_handlers(app)
    app.logger.info("Error handlers registered")
    
    # Setup rate limiting
    limiter = setup_rate_limiter(app)
    app.limiter = limiter
    
    # Register blueprints (routes)
    app.register_blueprint(health_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(audit_bp)
    app.logger.info("Blueprints registered")
    
    # Create logs directory
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    # Create test_emails directory
    if not os.path.exists('test_emails'):
        os.makedirs('test_emails')
    
    app.logger.info(f"Application running in {config.__name__} mode")
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)