# backend/config.py
"""Application Configuration"""

import os
from datetime import timedelta

class Config:
    """Base configuration"""
    
    # Flask
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    DEBUG = False
    TESTING = False
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URL',
        'postgresql://cnps_admin:testpass123@localhost:5432/cnps_2fa'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # AD/LDAP Configuration
    AD_SERVER = os.getenv('AD_SERVER', 'ldap://localhost:389')
    AD_DOMAIN = os.getenv('AD_DOMAIN', 'cnps-local.test')
    AD_BASE_DN = os.getenv('AD_BASE_DN', 'dc=cnps-local,dc=test')
    AD_USERNAME = os.getenv('AD_USERNAME', 'administrator')
    AD_PASSWORD = os.getenv('AD_PASSWORD', '')
    
    # Email Configuration
    EMAIL_PROVIDER = os.getenv('EMAIL_PROVIDER', 'mock')  # 'mock' or 'zimbra'
    EMAIL_FROM = os.getenv('EMAIL_FROM', 'noreply@cnps.cm')
    MAIL_SERVER = os.getenv('MAIL_SERVER', 'localhost')
    MAIL_PORT = int(os.getenv('MAIL_PORT', 25))
    MAIL_USERNAME = os.getenv('MAIL_USERNAME', '')
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', '')
    MAIL_USE_TLS = os.getenv('MAIL_USE_TLS', False)
    
    # Token Configuration
    TOKEN_LENGTH = 4
    TOKEN_CHARSET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    TOKEN_EXPIRY_MINUTES = 5
    MAX_TOKEN_ATTEMPTS = 3
    
    # Session Configuration
    SESSION_TIMEOUT_HOURS = 8
    SESSION_ABSOLUTE_TIMEOUT_HOURS = 12
    
    # Rate Limiting
    RATE_LIMIT_ENABLED = True
    RATE_LIMIT_PER_MINUTE = 5
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = 'logs/app.log'
    

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False


class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'  # Use in-memory SQLite for tests
    EMAIL_PROVIDER = 'mock'
    RATE_LIMIT_ENABLED = False


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False
    EMAIL_PROVIDER = 'zimbra'  # Use real Zimbra in production


def get_config():
    """Get configuration based on environment"""
    env = os.getenv('FLASK_ENV', 'development')
    configs = {
        'development': DevelopmentConfig,
        'testing': TestingConfig,
        'production': ProductionConfig
    }
    return configs.get(env, DevelopmentConfig)
