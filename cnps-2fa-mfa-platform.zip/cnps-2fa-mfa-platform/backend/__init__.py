# backend/__init__.py
"""CNPS 2FA MFA Platform - Backend Package"""

__version__ = "1.0.0"
__author__ = "CNPS Development Team"