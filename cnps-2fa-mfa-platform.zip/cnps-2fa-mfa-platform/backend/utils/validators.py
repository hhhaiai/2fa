# backend/utils/validators.py
"""Input Validation Functions"""

import re
from backend.utils.constants import ERROR_INVALID_CREDENTIALS

def validate_username(username):
    """
    Validate username format
    
    Args:
        username (str): Username to validate
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not username or not isinstance(username, str):
        return False, "Username is required"
    
    if len(username) < 3 or len(username) > 255:
        return False, "Username must be between 3 and 255 characters"
    
    # Allow alphanumeric, dots, underscores, hyphens
    if not re.match(r'^[a-zA-Z0-9._-]+$', username):
        return False, "Username contains invalid characters"
    
    return True, None


def validate_password(password):
    """
    Validate password format
    
    Args:
        password (str): Password to validate
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not password or not isinstance(password, str):
        return False, "Password is required"
    
    if len(password) < 1:
        return False, "Password cannot be empty"
    
    return True, None


def validate_email(email):
    """
    Validate email format
    
    Args:
        email (str): Email to validate
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not email or not isinstance(email, str):
        return False, "Email is required"
    
    # Simple email validation
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(email_pattern, email):
        return False, "Invalid email format"
    
    return True, None


def validate_app_name(app_name):
    """
    Validate application name
    
    Args:
        app_name (str): Application name to validate
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not app_name or not isinstance(app_name, str):
        return False, "Application name is required"
    
    if len(app_name) < 1 or len(app_name) > 255:
        return False, "Application name must be between 1 and 255 characters"
    
    return True, None


def validate_otp_code(otp_code):
    """
    Validate OTP code format
    
    Args:
        otp_code (str): OTP code to validate
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not otp_code or not isinstance(otp_code, str):
        return False, "OTP code is required"
    
    # OTP should be exactly 4 characters, alphanumeric
    if not re.match(r'^[A-Z0-9]{4}$', otp_code.upper()):
        return False, "OTP code must be exactly 4 alphanumeric characters"
    
    return True, None