# backend/utils/encryption.py
"""Encryption and Token Generation Utilities"""

import random
import string
import uuid
import hashlib
from backend.config import Config

def generate_4char_token():
    """
    Generate a random 4-character alphanumeric token
    Characters: A-Z and 0-9
    
    Returns:
        str: Random 4-character token (e.g., "ABC1")
    """
    chars = Config.TOKEN_CHARSET  # 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    token = ''.join(random.choice(chars) for _ in range(Config.TOKEN_LENGTH))
    return token


def generate_session_id():
    """
    Generate a unique session ID
    
    Returns:
        str: UUID v4 as string
    """
    return str(uuid.uuid4())


def generate_session_token():
    """
    Generate a secure session token (longer than OTP for better security)
    
    Returns:
        str: Randomly generated 64-character token
    """
    return ''.join(random.choices(string.ascii_letters + string.digits, k=64))


def hash_token(token):
    """
    Hash a token for secure storage
    
    Args:
        token (str): Token to hash
        
    Returns:
        str: SHA256 hash of token
    """
    return hashlib.sha256(token.encode()).hexdigest()


def generate_uuid():
    """
    Generate a UUID for records
    
    Returns:
        str: UUID v4 as string
    """
    return str(uuid.uuid4())