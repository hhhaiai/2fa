# backend/utils/constants.py
"""Application Constants"""

# Authentication Actions
ACTION_TOKEN_GENERATED = "token_generated"
ACTION_TOKEN_VALIDATED = "token_validated"
ACTION_LOGIN_SUCCESS = "login_success"
ACTION_LOGIN_FAILED = "login_failed"
ACTION_SESSION_REVOKED = "session_revoked"

# Status
STATUS_SUCCESS = "success"
STATUS_FAILURE = "failure"

# Error Messages
ERROR_INVALID_CREDENTIALS = "Invalid username or password"
ERROR_INVALID_TOKEN = "Invalid or expired token"
ERROR_TOKEN_EXPIRED = "Token has expired"
ERROR_MAX_ATTEMPTS = "Maximum attempt limit reached"
ERROR_SESSION_EXPIRED = "Session has expired"
ERROR_DATABASE = "Database error occurred"
ERROR_EMAIL_SEND = "Failed to send email"
ERROR_AD_CONNECTION = "Failed to connect to Active Directory"

# Success Messages
MSG_TOKEN_SENT = "OTP token sent successfully"
MSG_LOGIN_SUCCESS = "Login successful"
MSG_EMAIL_RECEIVED = "Email received with OTP"

# Token Settings
TOKEN_CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
TOKEN_LENGTH = 4