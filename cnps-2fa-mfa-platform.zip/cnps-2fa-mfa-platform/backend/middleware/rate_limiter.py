# backend/middleware/rate_limiter.py
"""Rate Limiting Middleware"""

from flask import request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import logging

logger = logging.getLogger(__name__)

def setup_rate_limiter(app):
    """
    Setup rate limiting for the application
    
    Args:
        app: Flask application instance
        
    Returns:
        Limiter: Flask-Limiter instance
    """
    
    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        default_limits=["200 per day", "50 per hour"],
        storage_uri="memory://"  # Use memory for in-process testing
    )
    
    logger.info("Rate limiter configured")
    
    return limiter