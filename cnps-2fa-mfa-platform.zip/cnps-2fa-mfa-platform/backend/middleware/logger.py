# backend/middleware/logger.py
"""Application Logging Setup"""

import logging
import os
from logging.handlers import RotatingFileHandler
from flask import request, g

def setup_logging(app):
    """
    Setup application logging
    
    Args:
        app: Flask application instance
    """
    
    # Create logs directory if it doesn't exist
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    # Configure root logger
    log_level = app.config.get('LOG_LEVEL', 'INFO')
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create rotating file handler
    file_handler = RotatingFileHandler(
        'logs/app.log',
        maxBytes=10485760,  # 10MB
        backupCount=10
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    ))
    
    # Add file handler to root logger
    logging.getLogger().addHandler(file_handler)
    
    # Log Flask app initialization
    app.logger.info("=" * 60)
    app.logger.info("CNPS 2FA MFA Platform - Application Started")
    app.logger.info("=" * 60)
    
    @app.before_request
    def before_request():
        """Log incoming requests"""
        g.start_time = __import__('time').time()
        app.logger.debug(f"Incoming {request.method} {request.path}")
    
    @app.after_request
    def after_request(response):
        """Log response and timing"""
        elapsed = __import__('time').time() - g.start_time
        app.logger.debug(
            f"Completed {request.method} {request.path} - "
            f"Status: {response.status_code} - "
            f"Time: {elapsed:.3f}s"
        )
        return response