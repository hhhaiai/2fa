# backend/models/user.py
"""User Model"""

from datetime import datetime
from sqlalchemy import Column, String, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class User(Base):
    """User model - stores user information from AD"""
    
    __tablename__ = 'users'
    
    username = Column(String(255), primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    full_name = Column(String(255))
    active = Column(Boolean, default=True)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<User {self.username}>"
    
    def to_dict(self):
        return {
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'active': self.active,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'created_at': self.created_at.isoformat(),
        }