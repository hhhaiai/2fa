# backend/models/audit_log.py
"""Audit Log Model"""

from datetime import datetime
from sqlalchemy import Column, String, DateTime, Integer, Text
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class AuditLog(Base):
    """Audit Log model - tracks all authentication events"""
    
    __tablename__ = 'audit_logs'
    
    id = Column(String(36), primary_key=True)
    username = Column(String(255))
    action = Column(String(100), nullable=False)  # 'token_generated', 'token_validated', 'login_success', etc.
    app_name = Column(String(255))
    status = Column(String(50))  # 'success', 'failure'
    reason = Column(Text)  # Reason for failure, if any
    ip_address = Column(String(45))  # Supports IPv4 and IPv6
    user_agent = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<AuditLog {self.action} by {self.username}>"
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'action': self.action,
            'app_name': self.app_name,
            'status': self.status,
            'reason': self.reason,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat(),
        }