# backend/models/token.py
"""OTP Token Model"""

from datetime import datetime
from sqlalchemy import Column, String, DateTime, Integer, Boolean
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class OTPToken(Base):
    """OTP Token model - stores generated 4-character tokens"""
    
    __tablename__ = 'otp_tokens'
    
    id = Column(String(36), primary_key=True)
    session_id = Column(String(36), nullable=False)
    username = Column(String(255), nullable=False)
    token = Column(String(4), nullable=False)
    app_name = Column(String(255), nullable=False)
    is_valid = Column(Boolean, default=True)
    failed_attempts = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    validated_at = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<OTPToken {self.session_id}>"
    
    def is_expired(self):
        """Check if token has expired"""
        return datetime.utcnow() > self.expires_at
    
    def is_valid_for_validation(self):
        """Check if token can still be validated"""
        return self.is_valid and not self.is_expired() and self.failed_attempts < 3
    
    def to_dict(self):
        return {
            'id': self.id,
            'session_id': self.session_id,
            'username': self.username,
            'app_name': self.app_name,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat(),
            'is_expired': self.is_expired(),
        }