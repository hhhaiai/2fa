# backend/models/session.py
"""Session Token Model"""

from datetime import datetime
from sqlalchemy import Column, String, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class SessionToken(Base):
    """Session Token model - issued after successful 2FA"""
    
    __tablename__ = 'session_tokens'
    
    id = Column(String(36), primary_key=True)
    username = Column(String(255), nullable=False)
    app_name = Column(String(255), nullable=False)
    token = Column(String(512), unique=True, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    revoked_at = Column(DateTime, nullable=True)
    last_activity = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<SessionToken {self.username}>"
    
    def is_expired(self):
        """Check if session has expired"""
        return datetime.utcnow() > self.expires_at
    
    def is_valid(self):
        """Check if session is still valid"""
        return self.is_active and not self.is_expired()
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'app_name': self.app_name,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat(),
            'is_expired': self.is_expired(),
        }
    